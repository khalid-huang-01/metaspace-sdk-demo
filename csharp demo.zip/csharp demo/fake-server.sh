#!/bin/bash

/local/app/csharp-fake-server/cshar-demo-self/csharp-demo-self/bin/Debug/netcoreapp3.1/csharpdemo
