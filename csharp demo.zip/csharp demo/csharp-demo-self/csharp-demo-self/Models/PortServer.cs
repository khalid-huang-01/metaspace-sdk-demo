using System;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text.RegularExpressions;

namespace CSharpDemo.Models
{
    public static class PortServer
    {
        public static int GenerateRandomPort(int minPort, int maxPort)
        {
            while (true)
            {
                int count = 0;
                int seed = Convert.ToInt32(Regex.Match(Guid.NewGuid().ToString(), @"\d+").Value);
                Random ran = new Random(seed);
                int port = ran.Next(minPort, maxPort);
                if (count < 1000 && !IsPortInUsed(port))
                {
                    return port;
                }
                count++;
            }
        }

        private static bool IsPortInUsed(int port)
        {
            IPGlobalProperties ipGlobalProperties = IPGlobalProperties.GetIPGlobalProperties();
            IPEndPoint[] ipsTCP = ipGlobalProperties.GetActiveTcpListeners();
            if (ipsTCP.Any(p=>p.Port==port))
            {
                return true;
            }

            IPEndPoint[] ipsUDP = ipGlobalProperties.GetActiveUdpListeners();
            if (ipsUDP.Any(p=>p.Port==port))
            {
                return true;
            }

            TcpConnectionInformation[] tcpConnInfoArray = ipGlobalProperties.GetActiveTcpConnections();
            if (tcpConnInfoArray.Any(conn=>conn.LocalEndPoint.Port==port))
            {
                return true;
            }
            return false;
        }
    }
}